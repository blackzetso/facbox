/**
 * @file Timeline view
 */
define(function (require) {

    // var zrUtil = require('zrender/core/util');
    // var graphic = require('../../util/graphic');
    var ComponentView = require('../../view/Component');

    return ComponentView.extend({

        type: 'timeline'
    });

});