 
    <nav class="nav nav-mobil  d-flex ">
        <div class="container d-flex align-items-center justify-content-center">
            <ul class="links d-flex align-items-center">
                <li><a href="index.php" class="active"><i class="fas fa-home icon"></i></a></li>
                <li><a href="acount.php"><i class="fas fa-user icon"></i></a></li>
                <li><a href="order.php"><i class="fas fa-address-book icon"></i></a></li>
                <li><a href="/contact.php"><i class="fas fa-paper-plane icon"></i></a></li>
                <?php echo account(); ?>
            </ul>
        </div>
    </nav> 