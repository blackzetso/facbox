// TODO boundaryGap
define(function(require) {
    'use strict';

    require('../coord/cartesian/AxisModel');

    require('./axis/AxisView');
});